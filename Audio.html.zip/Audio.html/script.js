const audio = document.getElementById('audio');
const playBtn = document.getElementById('play-btn');
const stopBtn = document.getElementById('stop-btn');
const seekbar = document.getElementById('seekbar');
const currentTimeElem = document.getElementById('current-time');
const durationElem = document.getElementById('duration');

// Play button functionality
playBtn.addEventListener('click', () => {
    audio.play();
});

// Stop button functionality
stopBtn.addEventListener('click', () => {
    audio.pause();
    audio.currentTime = 0; // Reset audio to the beginning
});

// Update seekbar and time display
audio.addEventListener('timeupdate', () => {
    const currentTime = audio.currentTime;
    const duration = audio.duration;

    currentTimeElem.textContent = formatTime(currentTime);
    durationElem.textContent = formatTime(duration);

    seekbar.value = (currentTime / duration) * 100;
});

// Seek functionality
seekbar.addEventListener('input', () => {
    const seekTime = (seekbar.value / 100) * audio.duration;
    audio.currentTime = seekTime;
});

// Format time in mm:ss
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}
